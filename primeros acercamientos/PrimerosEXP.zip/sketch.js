// Como esa noche de discoteca, cuando se baila, se goza, hay brillos, colores, cierro los ojos y solo vibro, pero tambien tengo en la mente el 7,8... //

// Esta pieza juega con el algoritmo, baila con él, lo ejecuta al ritmo del ordenador, dependiendo de tu maquina, es tu rendimiento, tu performance, en el mío dura como 20 seg en renderizarse, 56 es el frame de inicio para que aparezca la luz, en el 78 termina. Baila cuantas veces quieras, siempre sentiras difente. Petra 13/11/22 //

var colores = [
  "red",
  "orange",
  "purple",
  "pink",
  "yellow", 
  "green",
  "blue",
  "cyan",
  "brown",
];
var x = [];
var y = [];
var sz = [];
var col = [];
var seed = fxrand;
var noiseScale = 0.2;
var a;
var velocidad = []; 

function genR(min, max) { let result = 0; if (!max) { result = fxrand() * (min - 0) + 0; } else { result = fxrand() * (max - min) + min; } return result; }

function setup() {

  createCanvas(windowWidth-1, windowHeight-1);
  extraCanvas = createGraphics(windowWidth - 1, windowHeight - 1);
  
  a = height / 2;

  frameRate (10);

  for(var i = 0 ; i<8; i++){
    x = append(x,genR(width));
    y = append(y,genR(height));
    sz = append(sz, genR(50));
    velocidad = append(velocidad, genR(3)); 
  }
}

function draw() {
  background(255);

  image(extraCanvas, 0,0);

  for (var i = 0; i < x.length; i++) {
    x[i] += velocidad[i];  // Modifica la posición en x usando la velocidad específica para ese elemento
  
  extraCanvas.push();
    
    var steps = sz[i]*0.2;

    for (var j = 0; j < sz[i]; j += steps){
     
      let noiseVal = noise(noiseScale,  noiseScale * steps);

      let ang = genR(noiseVal); 
      
      // push();
      extraCanvas.translate(x[i], y[i]);

      extraCanvas.rotate(frameCount%360);
      // pop();

      let rotatedX = x[i] * Math.cos(ang) - y[i] * Math.sin(ang);
      let rotatedY = x[i] * Math.cos(ang) + y[i] * Math.sin(ang);

      if (rotatedX >= 0 && rotatedX <= width && rotatedY >= 0 && rotatedY <= height) {
      
        var r = j + sz[i];

        io = ang;

        var t = 0;

        while (t < r) {
          var x1 = t;
          var y1 = t;
          var x2 = 10 - t;
          var y2 = r % 360 + t;

          extraCanvas.stroke(colores[i]);
          extraCanvas.line(x1+steps, y1, x2, y2+a);
          t++;
      
          a = a - io;

          if (a < 0) {
            a = 1 - io;

          }
        }
      }
    }
    extraCanvas.pop();
  }

  if (frameCount == 25) {
    noLoop();
  }

  strokeWeight(20);
  stroke(0);
  noFill();
  rect(0, 0, width - 1, height - 1);

  if (isFxpreview == true) {
    fxpreview();
  }
  if (frameCount == 5) {
    extraCanvas.blendMode(ADD,BLEND);
  }
}
  


// DATA // 
function getFeatureString(value) {
  if (value
    < 0.5) return "low"
  if (value < 0.9) return "medium"
  else return "high"
}

window.$fxhashFeatures = {
  // feature can only be "low", "medium" or "high"
  "☁ Dance ☁": getFeatureString(fxrand())
}

