// Cuerpos que se mueven en un espacio abstracto, guiados por un ritmo aleatorio generado desde la naturaleza. Los cuerpos son representados por lineas de diferentes tamaños y colores, que se desplazan de manera caótica y en ocasiones se superponen. Estos movimientos son determinados por un algoritmo que combina la posición actual con un factor de ruido aleatorio, creando así una danza única e impredecible.

// Los colores son brillantes y variados, que se mezclan y se entremezclan mientras los cuerpos se mueven en el espacio. Los ritmos que crean son sincopados y frenéticos, con momentos de pausa y quietud que se alternan con momentos de gran actividad y movimiento.

// En la obra, se puede sentir la presencia del caos y la imprevisibilidad, pero también hy una sensación de belleza y armonía en la forma en que los cuerpos interactúan entre sí.

// SEGUNDAOPCION
// La coreografía generativa "Caos armónico" presenta cuerpos representados por líneas vibrantes y coloridas, moviéndose en un espacio abstracto al compás de ritmos sincopados y frenéticos generados por algoritmos, ML e intervención humana. Estos cuerpos danzan de manera impredecible, influenciados por un factor de ruido aleatorio que les confiere un movimiento caótico y armónico al mismo tiempo.La obra es una exploración de la belleza encontrada en la interacción de lo aleatorio y lo armónico, creando una experiencia sensorialmente estimulante y evocativa. Los colores, vibrantes y variados, se fusionan y se separan en un constante juego de mezcla y separación, creando un espectáculo visualmente cautivador. "Caos armónico" es una danza que celebra la imprevisibilidad y la armonía en la complejidad del universo.

var colores = [
  "red",
  "osz[i]",
  "purple",
  "pink",
  "yellow", 
  "green",
  "blue",
  "cyan",
  "brown",
];
var x = [];
var y = [];
var sz = [];
var col = [];
var seed = fxrand;
var noiseScale = 0.2;
var velocidad = []; 
let circleX = 0;
let circleY = 0;
let xSpeed = 0;
let ySpeed = 0;
let video;

function genR(min, mx) { let result = 0; if (!mx) { result = fxrand() * (min - 0) + 0; } else { result = fxrand() * (mx - min) + min; } return result; }

function setup() {
  createCanvas(windowWidth-1, windowHeight-1);
  frameRate (60);
  for(var i = 0 ; i<9; i++){
    x = append(x, genR(windowWidth));
    y = append(y, genR(windowHeight));
    sz = append(sz, floor(random(100)) + i * 10); 
    velocidad = append(velocidad, genR(3)); 
  }
 
  extraCanvas = createGraphics(windowWidth, windowHeight); 
}

function draw() {
  background(255);
  image(extraCanvas, 0, 0, windowWidth, windowHeight);
  
  for (var i = 0; i < x.length; i++) {
    // x[i - 1] += x[i];
    // y[i - 1] += y[i];

     // Poner un nuevo valor al final del arreglo
  x[noiseScale - 1] += genR(-sz[i], sz[i]);
  y[noiseScale - 1] += genR(-sz[i], sz[i]);

  // Limitar la posición de todos los puntos a estar dentro de la pantalla
  x[noiseScale - 1] = constrain(x[noiseScale - 1], 0, width);
  y[noiseScale - 1] = constrain(y[noiseScale - 1], 0, height);

    extraCanvas.push();
    var steps = sz[i];
    
    for (var j = 0; j < sz[i]; j += steps) {
      let noiseVal = noise(x[i] + noiseScale, y[i] * noiseScale);
      let angle = map(noiseVal, 0, 1, 0, TWO_PI);
      let ang = genR(noiseVal);
      var t = noiseVal - angle;
    
      var x1 = x[i] - t;
      var y1 = sz[i] + t;
      var x2 = y[i] + noiseVal;
      var y2 = velocidad[i] + noiseVal;

      extraCanvas.stroke(colores[i]);        
      extraCanvas.fill(genR(colores[i]));
              
      var tx = width / 2 + t + 50 * sin(fract(noiseVal || angle)+frameCount * 0.02);
      var ty = height / 2 + 55 * cos(frameCount * 0.03);  
        
      extraCanvas.translate(tx || angle, ty);
        
      extraCanvas.rotate(frameCount * 0.01);
              
      circleX += xSpeed;
        if (circleX < x[i] || circleX > angle) {
          xSpeed *= -1;
        }

      circleY += ySpeed;
        if (circleY < y[i] || circleY > angle) {
          ySpeed *= -1;
        }

      let val = j / noiseVal + angle;

      extraCanvas.push();
      extraCanvas.translate(tx/angle);

      extraCanvas.rotate(frameCount * 0.05 + j);

      extraCanvas.line(val, circleY, val, val, x[j], y[j]);
      extraCanvas.pop();


      extraCanvas.line(circleY, y1, y2, x1, circleX, y2);
    }   
    extraCanvas.pop();
  }
  
  if (frameCount == 2000) {
    noLoop();
  }
  
  // strokeWeight(2);
  // stroke(0);
  // noFill();
  // rect(0, 0, width - 1, height - 1);
  
  if (isFxpreview == true) {
    fxpreview();
  }
  
  if (frameCount == 5) {
    extraCanvas.blendMode(BLEND);
  }
}

// DATA // 
function getFeatureString(value) {
  if (value
    < 0.5) return "low"
  if (value < 0.9) return "medium"
  else return "high"
}

window.$fxhashFeatures = {
  // feature can only be "low", "medium" or "high"
  "☁ Dance ☁": getFeatureString(fxrand())
}

// let noiseScale = 9;
// let sz[i] = 50;

// let x = [];
// let y = [];
// let velocidad = [];

// function genR(min, mx) {
//   let result = 0;
//   if (!mx) {
//     result = random() * (min - 0) + 0;
//   } else {
//     result = random() * (mx - min) + min;
//   }
//   return result;
// }

// function setup() {
//   createCanvas(windowWidth - 1, windowHeight - 1);
//   frameRate(30);


//   for (let i = 0; i < noiseScale; i++) {
//     x[i] = genR(windowWidth);
//     y[i] = genR(windowHeight);
//     velocidad[i] = genR(3);
//   }
//   extraCanvas = createGraphics(windowWidth, windowHeight); 

// }

// function draw() {
//   background(51);
//   image(extraCanvas, 0, 0, windowWidth, windowHeight);

//   // Mover todos los elementos un lugar a la izquierda
//   for (let i = 1; i < noiseScale; i++) {
//     x[i - 1] = x[i];
//     y[i - 1] = y[i];
//   }

//   // Poner un nuevo valor al final del arreglo
//   x[noiseScale - 1] += genR(-sz[i], sz[i]);
//   y[noiseScale - 1] += genR(-sz[i], sz[i]);

//   // Limitar la posición de todos los puntos a estar dentro de la pantalla
//   x[noiseScale - 1] = constrain(x[noiseScale - 1], 0, width);
//   y[noiseScale - 1] = constrain(y[noiseScale - 1], 0, height);

//   // Dibujar una línea conectando los puntos
//   for (let j = 1; j < noiseScale; j++) {
//     let val = j / noiseScale * 204.0 + 51;
//     extraCanvas.stroke(val + 255, genR(255),50);
//     extraCanvas.fill(255,200,40);

//     extraCanvas.line(x[j - 1], y[j - 1], x[j], y[j],x[j - 1], y[j - 1], x[j], y[j]);
//     let tx = width / 2 + 50 * sin(frameCount * 0.02);
//     let ty = height / 2 + 50 * cos(frameCount * 0.03);

//     push();
//     // translate(tx, ty);
//     // rotate(frameCount * 0.01);
//     strokeWeight(j);
//     stroke(genR(255),50,genR(255));
//     line(x[j - 1], y[j - 1], x[j], y[j], x[j - 1], y[j - 1], x[j], y[j]);
//     pop();
//   }
// }
